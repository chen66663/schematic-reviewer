---
name: schematic-reviewer
description: 检查与审核原理图：读芯片数据手册做逐引脚分析，核对去耦、上拉、匹配等外围电路是否缺失或参数错误，识别大电流路径并按 IPC-2221 给出走线加宽建议，通过立创/JLC 接口核实元器件规格（耐压、额定电流、封装）与现货库存，最后按严重程度输出问题清单。当用户要求检查原理图、审核电路、判断原理图有没有问题、做元器件选型验证、立创选型、走线加宽、载流计算、外围电路检查、引脚功能核对、数据手册核对、BOM 核对，或提供了嘉立创 EDA 网表导出、BOM 导出、.tel 网表（含 $PACKAGES、$NETS）时使用。不适用于 PCB 布局的 DRC/阻抗检查、电路仿真、固件代码审查，也不检查铜柱、螺柱、螺钉、螺母、垫片等机械结构件。
---

# 原理图检查专家

## 环境适配

本技能运行在 Claude Code 下。执行任何脚本前，先定义两个变量：

```bash
SK="${CLAUDE_SKILL_DIR}/scripts"   # Claude Code 注入，指向本 skill 的 SKILL.md 所在目录
PY="python"                        # 脚本只用标准库；不要用 py 启动器
```

- `CLAUDE_SKILL_DIR` 由 Claude Code 替换为技能目录，技能装到 `~/.claude/skills` 或插件里都能用，不要写死路径。
- 脚本只依赖标准库，Python 3.8+ 可跑；已用 Python 3.11 与 3.9 验证（23 项回归测试全绿）。

- 路径一律用正斜杠 `/`；含空格的路径整段加双引号。后文所有命令都写成 `"$PY" "$SK/xxx.py"` 的形式。
- 技能装在别处时，把 `SK` 指向实际的 `scripts` 目录；`references/` 与 `tests/` 就在它的同级。
- 网络出口可直连 `jlcpcb.com`，实测返回真实库存数据；若报「无法访问元器件接口」，说明当前沙箱/代理拦截，如实告知用户，不要伪造参数。
- 本技能的交付物是**对话里的问题清单**，不是文件。用户明确要求时才落盘，且不要写 `.md` 报告。

## 输入分流（先判断拿到的是什么，再动手）

| 输入 | 第一步 | 能查到什么 |
|---|---|---|
| 原理图图片 / PDF | 直接读图，按第 2–4 步逐模块核对 | 全部电气项 |
| BOM 卡片、CSV/TSV 元件表 | `"$PY" "$SK/review_export.py" <文件>` | 器件参数、封装、库存；**查不到网络连接** |
| `.tel` 网表（`$PACKAGES`/`$NETS`） | `"$PY" "$SK/parse_tel_netlist.py" <文件>` | 引脚级连接；**查不到布局与线宽** |
| 只有口述电路 | 先问关键芯片型号与连接关系 | 不猜型号、不猜拓扑 |

## 输出原则

- **只列有问题的部分**，直接说哪里有问题、怎么改。不生成图片或 HTML，不写概述/总结/检查依据等报告套话；结果直接在对话里按第 6 步的格式列出，也不落盘成 `.md` 文件。
- **每条结论必须有依据**：数据手册页码或章节名、外部 checklist 条目、接口返回的实际参数、可复现的载流计算。
- **元器件关键参数必须查接口核实**——耐压、额定电流、功率等不凭记忆填写。
- **选型必须确认现货库存大于 0**，缺货件要标注并给出替代型号。
- **不检查机械结构件**：铜柱、螺柱、螺钉、螺母、垫片等机械件不纳入原理图审查、BOM 电气参数核对或库存核对，除非用户明确要求核对机械装配。
- 没有问题的方面不写；确实没问题就直接说“没发现明显问题”，不要凑内容。

## Gotchas（踩过的坑）

以下每条都是实际审查里出过错的地方，**优先级高于正文里的常规描述**；与正文冲突时以本节为准。

- **立创商城网页抓不到数据**：它是 JS 单页应用，抓 HTML 只能拿到空壳，元器件信息一律走 `"$SK/lcsc_lookup.py"` 接口。
- **按 C 编号查询必须精确比对返回的 `componentCode`**：接口会返回同系列近似型号，不比对就会把低耐压/低等级的兄弟料当成目标料。
- **不要给立创接口传 `componentLibraryType: "base"`**：会漏掉大量型号。
- **BOM/网表导出通常没有网络连接**：只有器件参数时，不能断言“去耦接到了哪个 VDD 引脚”“UART 有没有交叉”——这些要等带 `$NETS` 的 `.tel` 或原理图才能查。
- **`{Value}` / `{Datasheet}` 是原理图库的占位符，不是真实值**：不能拿 `{Value}` 核对容值/耐压，也不能把 `{Datasheet}` 当链接打开；只有占位符的器件一律列为“手册待补齐”。
- **自动网络名不是信号名**：`$1N14` 这类是工具自动生成的编号，不要当成信号功能去推理。
- **同一引脚出现在两个网络 = 明确错误；同一器件多个引脚在同一网络 ≠ 短路**：后者可能是并联功率脚、连接器双触点或内部功能脚，只能列为“待确认项”，必须查数据手册再判。
- **接口返回的 `dataManualUrl` 是在线阅读页，不是 PDF 直链**：手册优先从厂商官网取；下载后校验文件头是 `%PDF-`，出现 `<!doctype html>` 说明被拦，换来源。
- **接口参数与数据手册冲突时以数据手册为准**，并在结论里点出这处冲突，不要静默采用其中一个。
- **导出记录缺少精度或耐压**：只报“信息待确认”，不要直接判定设计错误。

## 本环境可用工具

| 任务 | 用什么 |
|---|---|
| 读原理图图片（PNG/JPG） | Read 工具直接查看图片，逐模块识别器件 |
| 读原理图 / 数据手册 PDF | Read 工具原生读 PDF（逐页提取文字与版式）；`*.pdf` 先用 Bash 下载并校验文件头为 `%PDF-` |
| 抓数据手册 / 外部 checklist | WebFetch 工具（首选，自动转 markdown）；静态 PDF 用 Bash `curl -L -o` 下载 |
| 立创商城等 JS 单页应用 | 走 `"$SK/lcsc_lookup.py"` 接口，**不要**用 WebFetch 抓商品页（拿不到数据）；确有交互需求时用 `web-access` 技能 |
| 快速预检嘉立创 EDA/BOM 导出 | `"$SK/review_export.py"`（解析、去重、并发、缓存、问题筛选） |
| 解析 BOM 卡片、CSV/TSV 元件表 | `"$SK/parse_schematic_export.py"`（需要原始清单或自定义输出时使用） |
| 解析 .tel 原理图网表 | `"$SK/parse_tel_netlist.py"`（含 `$PACKAGES` 与 `$NETS` 时使用） |
| 元器件规格与库存 | `"$SK/lcsc_lookup.py"`（见下） |
| 载流计算 | `"$SK/trace_width.py"`（见下） |

> 元器件信息一律走接口。立创商城网页是 JS 单页应用，抓 HTML 只能拿到空壳。

## 导出预检与解析

当输入是 BOM 卡片或带表头的 CSV/TSV 元件表时，**第一步直接运行快速预检**，不要逐行人眼拼接，也不要逐颗器件手工查询。解析器同时支持：

- 多行卡片：`封装 ! 型号+属性 ! 参数 ,`，下一行 `; 位号`。
- 同行卡片：`封装 ! 型号+属性 ! 参数 ; 位号`。
- CSV/TSV：至少包含位号列，以及型号/参数/封装中的一种；常见表头见 [references/eda-export-format.md](references/eda-export-format.md)。

```text
C0402 ! CC0402JRNPO9BN470容值:47pF;精度:±5%;额定电压:50V ! 47pF ,
        ; CC3
,
```

```bash
"$PY" "$SK/review_export.py" export.txt --jobs 6
"$PY" "$SK/review_export.py" export.txt --verbose
"$PY" "$SK/review_export.py" export.txt --json
```

预检会在一条命令内完成：

- 解析导出记录，汇总位号并按型号去重。
- 并发查询立创/JLC，默认 6 路并发、缓存 24 小时。
- 只输出需要处理的项目：解析告警、型号未精确匹配、无现货、封装冲突、参数冲突或关键参数无法核实。
- 已经自动核验通过的型号默认不输出内容，减少阅读和后续手工查询。

缓存与并发可按需调整：

```bash
"$PY" "$SK/review_export.py" export.txt --no-cache
"$PY" "$SK/review_export.py" export.txt --cache-ttl 3600 --jobs 8
"$PY" "$SK/review_export.py" export.txt --cache-file .review-cache.json
```

需要原始规范化清单时，再单独调用解析器：

```bash
"$PY" "$SK/parse_schematic_export.py" export.txt
"$PY" "$SK/parse_schematic_export.py" export.txt --format json
"$PY" "$SK/parse_schematic_export.py" export.txt --format lcsc
```

- 默认输出 `位号 | 封装 | 型号 | 参数值 | 关键属性 | 数据手册` 的 TSV。
- `--format json` 保留原始行号、解析告警和全部属性。
- `--format lcsc` 输出去重后的型号列表，可交给 `lcsc_lookup.py bom` 批量核实库存。
- 预检输出、格式细节、字段含义和证据边界见 [references/eda-export-format.md](references/eda-export-format.md)。

## .tel 网表

输入含 `$PACKAGES` 和 `$NETS`，或文件扩展名是 `.tel` 时，第一步运行：

```bash
"$PY" "$SK/parse_tel_netlist.py" netlist.tel
"$PY" "$SK/parse_tel_netlist.py" netlist.tel --pins U22
"$PY" "$SK/parse_tel_netlist.py" netlist.tel --net NRST
"$PY" "$SK/parse_tel_netlist.py" netlist.tel --format json
```

- `REF.PIN` 是连接证据：`U22.25` 表示位号 U22 的第 25 脚属于该网络。
- 不假设 `$PACKAGES`、`$NETS`、`$COMPONENTS`、`$NETWORKS` 等段落的出现顺序；先扫描全部 section，再按别名归类。
- 不假设器件种类固定；先以网表实际出现的封装、型号、位号和引脚连接为准，未知类别只报告可证明的拓扑问题。
- 解析 `$PACKAGES` 时保留字段状态：`{Value}` 表示 Value 属性未展开，不能拿它做容值/阻值/额定参数核对；`{Datasheet}` 表示 Datasheet 属性是占位符，不等于已经有可打开的数据手册。
- 如果器件记录同时带有真实 URL、型号和占位符，优先使用真实 URL；如果只有 `{Datasheet}`，把器件列为“手册待补齐”，不要把占位符当成型号或链接。
- 连线检查分两层：重复引脚、同一引脚跨两个网络、网络引用未定义位号属于解析错误；同一器件多个引脚出现在同一网络、重复网络段、单引脚网络属于“连线待确认项”，必须结合器件数据手册和引脚功能判断，不能直接判定短路。
- 先用 `--pins <位号>` 取 IC 引脚网络，再对照数据手册；不要把自动网络名（如 `$1N14`）当成信号功能。
- 解析告警（未连接电气位号、同一网络重复引脚、单引脚网络、未定义位号）直接作为问题列出；已识别的机械/定位件（如 Harwin 间隔柱、`TP`、`FID`、`MH`）不按未连接电气位号告警。
- 这种网表没有封装内的引脚名，也没有坐标，不能据此判断去耦是否靠近引脚或走线宽度。
- 器件型号和库存仍按第 5 步核实；`parse_schematic_export.py` 检测到 `$PACKAGES/$NETS` 时会明确拒绝并提示改用本解析器。

**关键边界**：如果导出内容只有封装、型号、参数和位号，没有明确的网络名与引脚连接，就不能据此断言去耦是否接到具体 VDD 引脚、上拉是否接到目标信号、UART 是否交叉或晶振网络是否正确。此时只能检查器件级参数、型号库存、封装、类别与明显缺失，并明确列出需要补网表或原理图才能完成的检查项。

## 元器件核实：立创/JLC 接口

```bash
"$PY" "$SK/lcsc_lookup.py" get C8734
"$PY" "$SK/lcsc_lookup.py" search "0603 100nF 50V X7R" --in-stock
"$PY" "$SK/lcsc_lookup.py" search "SOT-23 N-MOS 30V" --limit 5
"$PY" "$SK/lcsc_lookup.py" bom mpn_list.txt --jobs 6
```

脚本返回：立创编号、品牌、型号、封装、现货库存、阶梯价、`attributes` 规格参数、手册链接、商品页。

- 关键词既可以是型号，也可以是参数组合（`0603 100nF 50V X7R`），后者用于选型和找替代料。
- 与立创商城同源，数据即立创商品库，满足“以立创为准”的要求。
- `bom` 会按型号去重后并发查询；查询结果默认缓存 24 小时，卡片类导出优先直接使用 `review_export.py`。
- 接口、字段与注意事项详见 [references/lcsc-guide.md](references/lcsc-guide.md)。
- 脚本不可用时，直接 POST `https://jlcpcb.com/api/overseas-pcb-order/v1/shoppingCart/smtGood/selectSmtComponentList`，body 为 `{"currentPage":1,"pageSize":20,"keyword":"<关键词>"}`。

## 数据手册获取

1. 优先抓**厂商官网 PDF**（如 `https://www.st.com/resource/en/datasheet/<型号>.pdf`），一般可直接下载：`curl -L -o ds.pdf "<URL>"`（Git Bash；超时加 `--max-time 60`）。
2. 接口返回的 `dataManualUrl` 可作线索，但它是 LCSC 在线阅读页而非 PDF 直链。
3. 下载后校验文件头：`head -c 5 ds.pdf` 应为 `%PDF-`；若是 `<!doctype html>` 说明被拦，换来源。
4. 用 Read 工具读 PDF（原生逐页提取文字与版式），**必须读到**：Pin Configuration、Recommended Operating Conditions、
   Electrical Characteristics、Absolute Maximum Ratings、Application Information/Typical Application、
   Layout Guidelines。
5. 手册很长时按关键词定位（“pin description”、“decoupling”、“layout”、“application circuit”），不要逐页通读。
6. 下载不到 PDF 时，用 WebFetch 抓厂商在线版页面作次选，并明确标注依据是网页而非手册原文。

## 工作流程

按顺序执行，每一步的产出作为下一步的输入。用户只要求某一项检查时（如仅 `trace` 或仅 `bom`），只做对应步骤。

### 第 1 步：输入解析与器件清单

输入可能是原理图图片、原理图 PDF、网表/文本描述，或口头描述的电路。输入含 `$PACKAGES` 和 `$NETS` 时，第一步运行 `"$SK/parse_tel_netlist.py"`，用它的引脚网络作为连接证据。遇到 BOM 卡片（同行或换行位号均可）或带表头的 CSV/TSV 元件表时，第一步运行 `"$SK/review_export.py"` 完成解析、去重、批量核验和问题筛选；只有需要原始清单或自定义格式时才再调用 `"$SK/parse_schematic_export.py"`。

- 输出器件清单：`位号 | 型号 | 功能模块 | 关键引脚连接`
- 先从原始证据中区分“器件参数列表”和“网络连接列表”。只有器件参数而没有网络连接时，关键引脚连接不得猜测。
- 原理图模糊或型号无法辨认时，先列出可识别部分，明确告知用户哪些需要补充，**不要猜型号**。
- 用户只给了电路描述而没给图时，先问清输入形式，并索要关键芯片型号，不要凭空假设电路。

### 第 2 步：数据手册与引脚级分析

对每个 IC：

1. 按上面的方法拿到数据手册。
2. 逐个引脚记录约束：
   - 电源引脚：工作电压范围、是否需独立去耦、最大功耗/电流
   - 关键信号引脚：输入/输出/双向、是否需上拉或下拉、电平标准、是否开漏、驱动能力(mA)

产出：每个 IC 的引脚分析摘要，重点标注设计约束。

### 第 3 步：外围电路检查

1. 先抓外部 checklist 的相关章节，把它当作检查骨架（见 [references/external-resources.md](references/external-resources.md)）。
2. 结合数据手册的典型应用电路，逐项核对原理图。
3. 核心规则速查见 [references/peripheral-rules.md](references/peripheral-rules.md)，仅作补充，详细规则以外部 checklist 为准。

检查维度（按优先级）：

- **电源去耦**：每个 VDD 引脚旁是否有 0.1µF 去耦电容、是否靠近引脚；大容量储能电容；模拟/数字电源分离；陶瓷电容直流偏压降额
- **复位与配置引脚**：RESET 是否有上拉与滤波电容；strapping/配置引脚是否正确上下拉；是否有悬空输入引脚
- **时钟电路**：晶振负载电容是否匹配（CL = (C1×C2)/(C1+C2) + Cs，常见错误是 C1/C2 直接取 CL 值）
- **接口与电平匹配**：I2C 上拉及阻值是否匹配总线速度；UART TX/RX、SPI MOSI/MISO 是否交叉；跨电压域是否有电平转换；CAN 两端是否有 120Ω 终端电阻
- **模拟前端**：ADC 输入是否有抗混叠滤波；运放反馈极性；基准去耦；模拟/数字地单点连接
- **功率路径**：输入是否有反接保护、TVS、保险丝；LDO/DCDC 输入输出电容与反馈电阻；DCDC 电感饱和电流；感性负载续流二极管
- **ESD 与保护**：对外连接器是否有 ESD/TVS；TVS 钳位电压是否低于后级绝对最大额定值；高速信号 ESD 器件电容是否足够低

如果输入只有元件清单，上述项目按证据能力拆开：元件值、耐压、精度、温度系数、封装、库存可以检查；具体去耦位置、引脚上下拉、接口交叉和网络拓扑必须等原理图或带网络连接的网表补齐后再检查。导出记录缺少精度或耐压时，只报告“信息待确认”，不要直接判错。

产出：问题清单，每条包含位号/引脚、问题描述、依据、修改建议、严重程度。

### 第 4 步：载流路径分析与走线加宽

1. **识别大电流节点**：电源主输入、电机驱动、LED 驱动、DCDC 开关节点(SW)、功率地(PGND)、USB 5V、充电电路。
2. **估算电流**：从数据手册取 IC 最大电流或负载额定电流；DCDC 输入电流 ≈ 输出电流 × (Vout/Vin) / 效率；电机启动电流按额定 3~5 倍。
3. **算线宽**：用 `"$PY" "$SK/trace_width.py" width --current <A> --copper 1 --layer outer --dt 10`，
   默认 1oz 铜厚、外层、温升 ≤10℃，建议留 1.5~2 倍裕量。数据表见 [references/trace-current-table.md](references/trace-current-table.md)。
4. **地平面**：模拟地/功率地单点连接；大电流回路面积尽量小。

产出：`路径 | 估算电流 | 建议最小线宽 | 备注`

### 第 5 步：元器件选型核实

预检已自动核验通过的普通无源器件不再逐件重复查询。对预检告警项、IC、电源和接口继续核实规格与库存，必须核实的参数见 [references/lcsc-guide.md](references/lcsc-guide.md) 第三节。

- 优先使用 `review_export.py`；没有导出格式或需要单独补充查询时，再用 `"$SK/lcsc_lookup.py"`。
- 库存为 0 的器件必须标注，并给出至少 1 个有现货的替代型号。
- 参数以接口返回为准；接口参数与数据手册冲突时以数据手册为准，并指出冲突。

产出：`位号 | 型号 | 设计要求 | 核实参数 | 是否满足 | 库存状态 | 替代型号`

### 第 6 步：直接输出问题

按严重程度分组，逐条列出，简洁直接：

```
🔴 严重问题（必须改，否则电路不工作或损坏器件）：
1. [位号/位置] [问题] → [怎么改]（依据：手册第 X 页 / checklist 条目）

🟡 警告（建议改，影响稳定性、EMC 或寿命）：
1. ...

🔵 建议（可选优化）：
1. ...

走线加宽：
- [路径] 电流约 X A，建议线宽 ≥ X mm（1oz 外层，温升 ≤10℃）

元器件问题（立创核实）：
- [位号] [型号] 耐压/电流不足或缺货 → 建议用 [替代型号]（有现货）
```

严重程度判定：

- 🔴 严重：电路不工作、损坏器件、安全隐患（去耦缺失、耐压不足、电源短路、电平不匹配、ESD 缺失）
- 🟡 警告：影响稳定性、EMC 或寿命（去耦距离远、上拉阻值偏大、走线裕量不足）
- 🔵 建议：不影响基本功能的优化项

## 关键约束

1. 禁止凭记忆填写元器件耐压、电流、功率等参数，必须查接口核实。
2. 数据手册引用必须标注页码或章节名。
3. 检查规则优先引用外部权威 checklist（用 WebFetch 现抓），不要只依赖本地 references。
4. 用户未提供原理图文件时，先询问输入形式，不要凭空假设电路。
5. 载流计算默认 1oz 铜厚；用户指定其它铜厚时按比例换算并注明假设。
6. 解析嘉立创 EDA/BOM 导出时先运行 `"$SK/review_export.py"` 做一次批量预检；不得逐件重复查询已通过型号。
7. 解析含 `$PACKAGES` 与 `$NETS` 的 `.tel` 网表时先运行 `"$SK/parse_tel_netlist.py"`；引脚连接只以 `REF.PIN` 记录为准。
8. 跑脚本一律用「环境适配」里的 `$PY` 与 `$SK`，不要自己拼路径，避免命中系统里其它 Python。
